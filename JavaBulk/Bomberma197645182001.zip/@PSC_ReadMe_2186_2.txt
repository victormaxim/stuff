Title: __Bomberman 1.0 Complete__
Description: Bomberman!
2-4 players supported.
I made this game in less than a week (as a bonus game for my OAV Computer Science project) so there could be some bugs. But as far as I know, there aren't any. :p Please comment on this game and vote for it if you like it :) Though some pictures used in the game are ripped from other bomberman games, the complete source and it's logics are by me :)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=2186&lngWId=2

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
