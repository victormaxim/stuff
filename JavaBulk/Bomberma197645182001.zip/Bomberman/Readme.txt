================================================================================
                    Bomberman Version 1.0 by Sammy Leong
================================================================================

I made this game as a mini game for my OAV project.  I made it in less than a
week (most of the time finding pictures and sound files to use) so there could
still be some bugs.

Requirements:
    * Java Runtime Version 1.1.8+ to play the game
    * Swing 1.1.1+
    * Sound only works with Java Runtime Version 1.3.0+
    * JDK 1.3+ is needed in order to compile it

How to Run:
    * Correct paths to Java Runtimes must be set first: refer to JRE Readme

    * On Windows 2000, simply make a batch file with these lines:
         @echo off
         start javaw Main

    * On Windows 9x, simply make a batch file with these lines:
         @echo off
         javaw Main

    * ... then put the batch files into /Bomberman (the root directory of
      the game)

Send any further questions to me @
sammyleong@sympatico.ca or
sammy_leong@hotmail.com

ps, if you like the game, please vote for it. :p
================================================================================